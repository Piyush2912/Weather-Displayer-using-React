import React from 'react';
import { Text , Button , View , Image }  from 'react-native';


class AssetExample extends React.Component {
state = {
 data: null
}
 async handleClick() {
 //   alert('Clicked')
  var url="https://api.openweathermap.org/data/2.5/weather?q=Delhi&appid=632d699905207c54e4be3b3be418213d"
  var response = await fetch(url)
  var data = await response.json()
 // alert(data.main.temp - 273.15)
   this.setState({data : data})
 }
 render() {
   // for display
   return (
   <View>
     <Text>{ this.state.data? this.state.data.main.temp : ""}</Text>
     {  this.state.data?<Image style={{width:50 ,height:50}}
      source={{
      uri:"https://openweathermap.org/img/w/"+this.state.data.weather[0].icon+".png"
      }} />
     : 
     null
     }
     <Button title="Get weather" onPress={ ()=>{this.handleClick()}} />  
     </View>
   )
 }
}

export default AssetExample;

